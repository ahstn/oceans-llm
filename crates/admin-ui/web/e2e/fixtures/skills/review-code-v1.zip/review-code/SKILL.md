---
name: review-code
description: Review code using a repeatable checklist.
metadata:
  author: example-org
  version: "1.0"
  github: https://github.com/example-org/review-skills/tree/main/review-code
---
# Review code

Use checklist version 1.
