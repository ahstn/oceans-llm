Checklist version 1: verify behavior and ownership.
