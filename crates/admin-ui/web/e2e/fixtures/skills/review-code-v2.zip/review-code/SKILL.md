---
name: review-code
description: Review code using a repeatable checklist.
metadata:
  author: example-org-contributors
  version: "2.0"
  github: http://github.com/example-org/review-skills
---
# Review code

Use checklist version 2.
