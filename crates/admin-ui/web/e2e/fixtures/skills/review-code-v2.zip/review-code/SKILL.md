---
name: review-code
description: Review code using a repeatable checklist.
---
# Review code

Use checklist version 2.
