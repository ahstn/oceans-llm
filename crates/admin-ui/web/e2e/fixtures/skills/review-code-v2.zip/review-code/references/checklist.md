Checklist version 2: verify behavior and ownership.
